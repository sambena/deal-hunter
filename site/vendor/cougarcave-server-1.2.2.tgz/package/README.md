# @cougarcave/server

The server half of every Cougar Cave app: Fastify with everything apps do the same way built in. An app adds only its own routes.

```ts
import { createApp, loadConfig } from '@cougarcave/server';

const app = await createApp({ name: 'Kitchen', slug: 'kitchen', config: loadConfig(), publicDir: new URL('../dist/public/', import.meta.url), routes });
await app.listen({ host: app.cave ? loadConfig().HOST : '127.0.0.1', port: loadConfig().PORT });
```

`create-cougar-app` writes this for you.

## What is built in

| Area | What it does |
|---|---|
| Security | Strict page policy (scripts, styles, images and fonts only from the app and `https://cougarcave.dev`; no inline code, no `data:` images), the usual hardening headers, `no-store` by default. Every POST, PUT, PATCH and DELETE needs `X-Cave-Request: 1`. Errors are `{ "error": <code>, "message": <text> }`, and a crash never shows its details. |
| Sign-in | Cougar Cave central login (OIDC, authorization code with PKCE, state and nonce) or, for local work only, the dev login. Sessions last 30 days, or 7 idle; only their hashes are stored. Sign-in URLs are kept out of logs. |
| Sign-out | `POST /auth/signout` returns the central sign-out address. A back-channel logout with a `sid` ends only that sign-in's sessions and phones; with only `sub`, all of that person's. A valid token for someone the app never saw gets 200; a replay or a bad token gets 400. |
| Phones | The pairing contract (`docs/work/502-*.md`): Add a phone gives a 6-digit PIN and a QR; the phone gets its own credential, rotated daily with a 60 s grace and a replayable lost reply. 3 failed tries from anywhere kill every outstanding PIN. |
| AI | `app.cave.ai.run(account, { messages, schema }, { accountLimitUsd })`: Claude, ChatGPT or Gemini, as the owner console's shared settings file says. It calls only the model the console published for the app, at the prices published with it (`use`, #923); with nothing published, AI is off. Each call is priced first, refused over the per-call cap or either monthly limit, and recorded from the provider's own usage. The reply is checked against your zod schema. |
| Files | The app's page files at `/`, the UI kit at `/cave/`, and `/healthz`. |
| Side data | Sign-in sessions, sign-ins in progress, paired phones, used sign-out tokens, rate-limit counters, the audit log and the AI spend record. With `createApp({ sideData: 'database' })` they are kept in the app's own schema: cave-db live (Library 132), PGlite locally. On the first start an existing `DATA_DIR/cave.db` is copied in once, so nobody signs in or pairs a phone again and the month's AI spend still counts; the file is left as it was. Without it (the default for now) they stay in `DATA_DIR/cave.db`. In the database the AI ledger also has a totals-only view, `cave_ai_month` (app, month, billed, calls), granted to cave-db's `cave_spend` role so the owner console can show each app's spend (Den #924); it never shows an account, a person or a model. Either way `app.cave.side` reads and writes them (async, `?` placeholders, `cave_` table names); `app.cave.store`, the file itself, works only without `sideData: 'database'`. |
| Phone app | `createApp({ sideData: 'database', phoneApp: true })` keeps the app's Android releases in its own schema (`cave_app_releases`, `cave_app_files`; the last two releases) and serves them to signed-in people: `GET /api/app/android` (what the Android kit's `CaveUpdater` reads) and `GET /download/android/<file>` (`app.apk` is the universal APK). `publishRelease(db, folder)` adds a release from a GitHub release's files (`android.json` and its APKs): every size and sha256 must match, and the version must be newer. Run it from the app's own admin command, where the app runs. |

## Routes

```ts
app.get('/api/pantry', { config: { signedIn: true } }, async (req) => { /* req.session.person */ });
app.post('/api/devices/thing', { config: { browserOnly: true } }, handler);  // never from a paired phone
throw new Refusal(409, 'already_there', 'That item is already in the pantry.');
```

- `signedIn: true`: a signed-in person (browser or paired phone), or 401 `signed_out`.
- An app's own Bearer credential: `Authorization: Bearer` without the framework's `cave_` prefix passes through with `req.session` null and no cookie read, for a route that checks a key the app issued itself. `signedIn` routes still refuse it. Its writes need no `X-Cave-Request`: that rule protects cookie sessions, and another site's page can't set `Authorization` without a CORS preflight, which is never granted. The framework's own phone credentials keep every rule.
- `browserOnly: true`: a paired phone gets 403 `bearer_not_allowed`, never 401, which would make it unpair.
- `tokenOnly: true`: the route checks its own token (an agent API, for example). No cookie or phone credential is read for it (`req.session` is null), so the X-Cave-Request rule is skipped too. The route must authenticate every request. Not with `signedIn` or `browserOnly`.
- Fastify's own `bodyLimit` on a route raises the 1 MB default for that route only, such as an upload; a larger body elsewhere still gets 413 `too_large`.
- `req.session`: `{ kind: 'browser' | 'device', person: { subject, name, email, role }, sid, authTime }`, or `null`. `role` is `owner` when the person is on the app's `OWNERS` list, however they signed in: the login service asks for what the app's sign-in setting requires (password, code, either or both), and one sign-in counts in every app. Since 1.2.1 it is worked out on every request, so sessions and phones stored as a member under the earlier second-factor rule are the owner's again. Privileged actions still ask for a fresh password and code (`isFresh`, `bothFactors`).
- `isFresh(req.session, now, policy?)`: a recent sign-in, for privileged actions: the last hour by default, or as the owner console sets it for every app (`SIGNIN_POLICY_FILE`), or just being signed in when the owner switched the check off. Send people to `/auth/login?reauth=1` for a fresh one.
- `bothFactors(req.session)`: the sign-in used a password and a second factor (the ID token's `amr` has `pwd` and `mfa`; kept as `req.session.amr`). Never true for a phone. Use it with `isFresh` for privileged actions.
- `policy: { extend, paths }` in `createApp`: sources an app adds to the strict page policy, everywhere (`extend`) or for paths starting with a prefix (`paths: { '/cast/': {...} }`). Only safe additions are accepted, and anything else stops the app at start: `data:`/`blob:` images and media, `'wasm-unsafe-eval'`, https hosts, and `*` for connections, images and media. Never anything inline or `eval`, and never `data:` scripts or styles.
- `onLogout(subject, sid)` and `ignoreLogout(subject, sid)` in `createApp`: for what an app keeps itself (its own device keys) on a back-channel logout. `onLogout` is called after the framework has ended its own sessions and phones; `subject` is null when only an unknown sid was named. `ignoreLogout` is asked first: true marks the app's own session (one it opened and ended itself), and then the framework ends nothing and calls nothing, though the token still counts as used. Both fail closed: if `ignoreLogout` throws, the logout goes ahead. If `onLogout` throws, the framework's own sessions have already ended; the error is logged, without the token or the person, and the logout is answered as processed.
- `rawHosts: { 'gate.example.test': (req, res) => … }` in `createApp`: requests whose Host is exactly that name (any case, any port) go to the raw Node handler before every framework rule: no policy or headers, no X-Cave-Request check, no body parsing, no session. For a gate that proxies another service (streaming, uploads); the handler checks who may use it. The app's own host can't be one.
- `managedRawHosts: new ManagedRawHosts()` explicitly enables a separate trusted in-process host set, including when initially empty. After startup, `registry.replace({ 'gate.example.test': handler })` atomically replaces that whole managed set; `registry.snapshot()` reads the installed names and revision. `replace({})` removes it. Static `rawHosts`, the app's own name and their trailing-dot aliases stay reserved. No HTTP control route is added. The handlers still own all access checks; staged handlers must check active authority before proxying. Closing the app closes its registry.

## Settings

All from the environment, checked at start-up. Secrets are read from files.

| Setting | Default | Meaning |
|---|---|---|
| `APP_ORIGIN` | (required) | The address people use; cookies, redirects and QR codes use it |
| `HOST`, `PORT` | `127.0.0.1`, `8430` | Where to listen |
| `DATA_DIR` | `./data` | Local work's PGlite (`pg/`) and, for an app without `sideData: 'database'`, its side data file (`cave.db`) |
| `DEV_LOGIN` | off | The local stand-in for sign-in: 127.0.0.1 and http only |
| `OIDC_ISSUER`, `OIDC_CLIENT_ID`, `OIDC_CLIENT_SECRET_FILE` | | Cougar Cave sign-in, from the owner console's Add app |
| `OWNERS` | | Central subjects who are this app's owners (comma-separated) |
| `TRUSTED_PROXIES` | | Proxies whose `X-Forwarded-*` headers are trusted |
| `AI_SETTINGS_FILE` | `/run/cougar-ai/settings.json` | The owner console's shared AI settings, mounted read-only |
| `SIGNIN_POLICY_FILE` | `/run/cougar-policy/signin.json` | How recent a sign-in must be (adding a phone, a reauth) or whether to ask at all, set for every app in the owner console and mounted read-only. No file, or a broken one, means one hour; only the owner's switch turns it off |
| `AI_CALL_MAX_USD`, `AI_MAX_TOKENS` | `0.02`, `1024` | One AI call's limits |
| `AI_FAKE` | off | The no-cost fake AI provider, with the dev login only |
| `SHARED_ORIGIN` | `https://cougarcave.dev` | Where the shared bar and app list load from |

## Tests

### Inline AI images (Kitchen #511 prerequisite, #744)

Text-only messages keep their existing contract. A user turn can also carry
`images: [{ mediaType: 'image/jpeg', data: bytes.toString('base64') }]`.
`AIImage` is exported; PNG and WebP are also accepted. Supply canonical base64 bytes, never a URL or file path.
Malformed base64, unrecognized image headers, a mismatched media type or images on an assistant turn produce
400 `ai_image_invalid` before token counting. Header checks do not fully decode or sanitize an image.
The caller must bound uploads and image dimensions, strip metadata and dispose of its photo buffers/files.
The helper does not store image bytes, create provider files or fetch remote image URLs.

Both `estimate(request)` and `run(account, request, limits)` send images to the configured provider's counting
endpoint; estimation is therefore an external transmission even though it does not generate an answer.
Counting happens before generation budget reservation: obtain the person's consent before estimating too.
Generation uses the same inline image payload. Image input tokens participate in the existing typical/worst-case
estimate, per-call cap, household/app monthly reservation and provider-usage settlement, including invalid replies.
Gemini retains its conservative schema allowance. No image-token approximation or new provider/model default is added.
An unsupported model or failed count is refused through the existing provider error handling; it never falls back
to a text-only request. The fake accepts the same request and uses deterministic synthetic usage, without network.

Provider wire formats: [Anthropic vision](https://platform.claude.com/docs/en/build-with-claude/vision),
[OpenAI vision](https://developers.openai.com/api/docs/guides/images-vision),
[Gemini image understanding](https://ai.google.dev/gemini-api/docs/image-understanding).
Counting contracts: [OpenAI token counting](https://developers.openai.com/api/docs/guides/token-counting),
[Gemini tokens](https://ai.google.dev/gemini-api/docs/tokens).
No real provider execution is part of this prerequisite's automated checks.

### Paw AI conversations (server only)

`PawAIAdapter` wraps the existing `app.cave.ai`; it creates no settings, provider, ledger or authentication service.
Construct `new PawAIAdapter(app.cave.ai, authorize)` in the server. `authorize(context, conversationId)` must
resolve the currently authenticated central subject, check current conversation/account membership and revocation,
and return `{ account, person, accountLimitUsd }`, or `null` to deny. These are authoritative server values.
The shared `Session.person.subject` identifies a person; it does **not** establish an account membership.
Paw computer certificates, OS usernames and display names do not establish that membership either.

`run(context, { conversationId, messages })` accepts a UUID and up to 32 user/assistant text turns (8000 characters
each, 32000 total, ending in a user turn). Lab must build this input from authorized stored history, after checking
the desktop's request. Do not pass an arbitrary desktop transcript as authoritative history. Client account,
person, budgets, system prompts, models and tools are rejected. The result is the existing `AIResult<{text:string}>`.
Existing refusal codes and accounting apply; the host should use its normal safe error response handling.
Authorization is checked on each invocation; this adapter is not a transport route or an identity verifier.

`capabilities` reports `{ cancellation: false, actions: false }`: the existing helper/provider interface cannot
cancel an in-flight request. A UI may stop displaying a reply, but must not claim provider cancellation or reverse
ledger charges. Replies are text proposals only; executing an action requires the application's separate explicit
authorization and Jobs flow. Provider keys and this adapter remain on the server. Paid-provider execution,
end-to-end Lab routing and Paw UI acceptance are separate integration work.

`npm test`: settings, security, sign-in, back-channel logout, pairing and AI. Each refusal is checked for its code beside a working control, and the important rules have been break-checked (each one, when broken, fails a test).

## Apps with their own AI ledger

With database side data, set `createApp({ sideData: 'database', aiSpendView: 'app' })` if the app maintains its own `cave_ai_month` view. The framework still creates its side tables, copies an existing side-data file and enforces its AI limits, but does not create, replace or grant access to that view. This also works on the first start before the app creates its view.

The app must create a totals-only view with `app`, `month`, `billed_micros` and `calls`, and grant the existing `cave_spend` role SELECT on the view and USAGE on its schema. Never expose people, accounts, models or ledger rows. Keep the view definition and grants in the app's migrations or startup. Without this option, the framework continues to maintain its own view on every start. Switching back to the default replaces an app view, so migrate deliberately.
