# @cougarcave/server

The server half of every Cougar Cave app: Fastify with everything apps do the same way built in. An app adds only its own routes.

```ts
import { createApp, loadConfig } from '@cougarcave/server';

const app = await createApp({ name: 'Kitchen', slug: 'kitchen', config: loadConfig(), publicDir: new URL('../dist/public/', import.meta.url), routes });
await app.listen({ host: app.cave ? loadConfig().HOST : '127.0.0.1', port: loadConfig().PORT });
```

`create-cougar-app` writes this for you.

## What is built in

| Area | What it does |
|---|---|
| Security | Strict page policy (scripts, styles, images and fonts only from the app and `https://cougarcave.dev`; no inline code, no `data:` images), the usual hardening headers, `no-store` by default. Every POST, PUT, PATCH and DELETE needs `X-Cave-Request: 1`. Errors are `{ "error": <code>, "message": <text> }`, and a crash never shows its details. |
| Sign-in | Cougar Cave central login (OIDC, authorization code with PKCE, state and nonce) or, for local work only, the dev login. Sessions last 30 days, or 7 idle; only their hashes are stored. Sign-in URLs are kept out of logs. |
| Sign-out | `POST /auth/signout` returns the central sign-out address. A back-channel logout with a `sid` ends only that sign-in's sessions and phones; with only `sub`, all of that person's. A valid token for someone the app never saw gets 200; a replay or a bad token gets 400. |
| Phones | The pairing contract (`docs/work/502-*.md`): Add a phone gives a 6-digit PIN and a QR; the phone gets its own credential, rotated daily with a 60 s grace and a replayable lost reply. 3 failed tries from anywhere kill every outstanding PIN. |
| AI | `app.cave.ai.run(account, { messages, schema }, { accountLimitUsd })`: Claude, ChatGPT or Gemini, as the owner console's shared settings file says. Each call is priced first, refused over the per-call cap or either monthly limit, and recorded from the provider's own usage. The reply is checked against your zod schema. |
| Files | The app's page files at `/`, the UI kit at `/cave/`, and `/healthz`. |

## Routes

```ts
app.get('/api/pantry', { config: { signedIn: true } }, async (req) => { /* req.session.person */ });
app.post('/api/devices/thing', { config: { browserOnly: true } }, handler);  // never from a paired phone
throw new Refusal(409, 'already_there', 'That item is already in the pantry.');
```

- `signedIn: true`: a signed-in person (browser or paired phone), or 401 `signed_out`.
- An app's own Bearer credential: `Authorization: Bearer` without the framework's `cave_` prefix passes through with `req.session` null and no cookie read, for a route that checks a key the app issued itself. `signedIn` routes still refuse it. Its writes need no `X-Cave-Request`: that rule protects cookie sessions, and another site's page can't set `Authorization` without a CORS preflight, which is never granted. The framework's own phone credentials keep every rule.
- `browserOnly: true`: a paired phone gets 403 `bearer_not_allowed`, never 401, which would make it unpair.
- `tokenOnly: true`: the route checks its own token (an agent API, for example). No cookie or phone credential is read for it (`req.session` is null), so the X-Cave-Request rule is skipped too. The route must authenticate every request. Not with `signedIn` or `browserOnly`.
- Fastify's own `bodyLimit` on a route raises the 1 MB default for that route only, such as an upload; a larger body elsewhere still gets 413 `too_large`.
- `req.session`: `{ kind: 'browser' | 'device', person: { subject, name, email, role }, sid, authTime }`, or `null`.
- `isFresh(req.session, now, policy?)`: a recent sign-in, for privileged actions: the last hour by default, or as the owner console sets it for every app (`SIGNIN_POLICY_FILE`), or just being signed in when the owner switched the check off. Send people to `/auth/login?reauth=1` for a fresh one.
- `bothFactors(req.session)`: the sign-in used a password and a second factor (the ID token's `amr` has `pwd` and `mfa`; kept as `req.session.amr`). Never true for a phone. Use it with `isFresh` for privileged actions.
- `policy: { extend, paths }` in `createApp`: sources an app adds to the strict page policy, everywhere (`extend`) or for paths starting with a prefix (`paths: { '/cast/': {...} }`). Only safe additions are accepted, and anything else stops the app at start: `data:`/`blob:` images and media, `'wasm-unsafe-eval'`, https hosts, and `*` for connections, images and media. Never anything inline or `eval`, and never `data:` scripts or styles.
- `onLogout(subject, sid)` and `ignoreLogout(subject, sid)` in `createApp`: for what an app keeps itself (its own device keys) on a back-channel logout. `onLogout` is called after the framework has ended its own sessions and phones; `subject` is null when only an unknown sid was named. `ignoreLogout` is asked first: true marks the app's own session (one it opened and ended itself), and then the framework ends nothing and calls nothing, though the token still counts as used. Both fail closed: if `ignoreLogout` throws, the logout goes ahead. If `onLogout` throws, the framework's own sessions have already ended; the error is logged, without the token or the person, and the logout is answered as processed.
- `rawHosts: { 'gate.example.test': (req, res) => … }` in `createApp`: requests whose Host is exactly that name (any case, any port) go to the raw Node handler before every framework rule: no policy or headers, no X-Cave-Request check, no body parsing, no session. For a gate that proxies another service (streaming, uploads); the handler checks who may use it. The app's own host can't be one.

## Settings

All from the environment, checked at start-up. Secrets are read from files.

| Setting | Default | Meaning |
|---|---|---|
| `APP_ORIGIN` | (required) | The address people use; cookies, redirects and QR codes use it |
| `HOST`, `PORT` | `127.0.0.1`, `8430` | Where to listen |
| `DATA_DIR` | `./data` | The app's small SQLite file (`cave.db`): sessions, phones, AI ledger |
| `DEV_LOGIN` | off | The local stand-in for sign-in: 127.0.0.1 and http only |
| `OIDC_ISSUER`, `OIDC_CLIENT_ID`, `OIDC_CLIENT_SECRET_FILE` | | Cougar Cave sign-in, from the owner console's Add app |
| `OWNERS` | | Central subjects who are this app's owners (comma-separated) |
| `TRUSTED_PROXIES` | | Proxies whose `X-Forwarded-*` headers are trusted |
| `AI_SETTINGS_FILE` | `/run/cougar-ai/settings.json` | The owner console's shared AI settings, mounted read-only |
| `SIGNIN_POLICY_FILE` | `/run/cougar-policy/signin.json` | How recent a sign-in must be (adding a phone, a reauth) or whether to ask at all, set for every app in the owner console and mounted read-only. No file, or a broken one, means one hour; only the owner's switch turns it off |
| `AI_CALL_MAX_USD`, `AI_MAX_TOKENS` | `0.02`, `1024` | One AI call's limits |
| `AI_FAKE` | off | The no-cost fake AI provider, with the dev login only |
| `SHARED_ORIGIN` | `https://cougarcave.dev` | Where the shared bar and app list load from |

## Tests

`npm test`: settings, security, sign-in, back-channel logout, pairing and AI. Each refusal is checked for its code beside a working control, and the important rules have been break-checked (each one, when broken, fails a test).
