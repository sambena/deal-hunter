# @cougarcave/server

The server half of every Cougar Cave app: Fastify with everything apps do the same way built in. An app adds only its own routes.

```ts
import { createApp, loadConfig } from '@cougarcave/server';

const app = await createApp({ name: 'Kitchen', slug: 'kitchen', config: loadConfig(), publicDir: new URL('../dist/public/', import.meta.url), routes });
await app.listen({ host: app.cave ? loadConfig().HOST : '127.0.0.1', port: loadConfig().PORT });
```

`create-cougar-app` writes this for you.

## What is built in

| Area | What it does |
|---|---|
| Security | Strict page policy (scripts, styles, images and fonts only from the app and `https://cougarcave.dev`; no inline code, no `data:` images), the usual hardening headers, `no-store` by default. Every POST, PUT, PATCH and DELETE needs `X-Cave-Request: 1`. Errors are `{ "error": <code>, "message": <text> }`, and a crash never shows its details. |
| Sign-in | Cougar Cave central login (OIDC, authorization code with PKCE, state and nonce) or, for local work only, the dev login. Sessions last 30 days, or 7 idle; only the hash of a session's cookie is stored, next to the sign-in's ID token (kept for sign-out, see below; it holds the person's name and email and opens nothing in an app). Sign-in URLs are kept out of logs. |
| Sign-out | `POST /auth/signout` ends this browser's session and returns the central sign-out address. Since 1.2.8 that address carries the sign-in's ID token as `id_token_hint` next to `post_logout_redirect_uri` (`<origin>/auth/logout`): the login service refuses a return address without the hint ("Bad Request", Den 1078). The token is kept with the session (`cave_sessions.id_token`), used for nothing else, and never logged; the login service accepts it after it has expired. A session with no token (made before 1.2.8, or by the dev login) gets the address with neither, so the login service still ends its sign-in and the person stays on its signed-out page. If the browser has a sign-in at the login service that was started and never finished, the login service answers its sign-out address with an empty page; an app can't see or clear that, and opening the app again works. A back-channel logout with a `sid` ends only that sign-in's sessions and phones; with only `sub`, all of that person's. Either way only what existed when the token was issued (its `iat`, with 30 s of leeway): a notice delivered late, after the person signed in again, leaves the newer sign-in alone. A valid token for someone the app never saw gets 200; a replay or a bad token gets 400. |
| Phones | The pairing contract (`docs/work/502-*.md`): Add a phone gives a 6-digit PIN and a QR; the phone gets its own credential, rotated daily with a 60 s grace and a replayable lost reply. 3 failed tries from anywhere kill every outstanding PIN. |
| AI | `app.cave.ai.run(account, { messages, schema }, { accountLimitUsd })`: Claude, ChatGPT or Gemini, as the owner console's shared settings file says. It calls only the model the console published for the app, at the prices published with it (`use`, #923); with nothing published, AI is off. Each call is priced first, refused over the per-call cap or a monthly limit (the account's, the app's, or the owner's overall limit for all apps together, #925), and recorded from the provider's own usage. The overall limit is checked against cave-db's `core.ai_month_total`; if that can't be read the call is refused (`ai_overall_unknown`), never guessed. The reply is checked against your zod schema. |
| Files | The app's page files at `/`, the UI kit at `/cave/`, and `/healthz`. |
| Side data | Sign-in sessions, sign-ins in progress, paired phones, used sign-out tokens, rate-limit counters, the audit log and the AI spend record. With `createApp({ sideData: 'database' })` they are kept in the app's own schema: cave-db live (Library 132), PGlite locally. On the first start an existing `DATA_DIR/cave.db` is copied in once, so nobody signs in or pairs a phone again and the month's AI spend still counts; the file is left as it was. Without it (the default for now) they stay in `DATA_DIR/cave.db`. In the database the AI ledger also has a totals-only view, `cave_ai_month` (app, month, billed, calls), granted to cave-db's `cave_spend` role so the owner console can show each app's spend (Den #924); it never shows an account, a person or a model. Either way `app.cave.side` reads and writes them (async, `?` placeholders, `cave_` table names); `app.cave.store`, the file itself, works only without `sideData: 'database'`. |
| Phone app | `createApp({ sideData: 'database', phoneApp: true })` keeps the app's Android releases in its own schema (`cave_app_releases`, `cave_app_files`; the last two releases) and serves them to signed-in people: `GET /api/app/android` (what the Android kit's `CaveUpdater` reads) and `GET /download/android/<file>` (`app.apk` is the universal APK). `publishRelease(db, folder)` adds a release from a GitHub release's files (`android.json` and its APKs): every size and sha256 must match, and the version must be newer. Run it from the app's own admin command, where the app runs. |

## Routes

```ts
app.get('/api/pantry', { config: { signedIn: true } }, async (req) => { /* req.session.person */ });
app.post('/api/devices/thing', { config: { browserOnly: true } }, handler);  // never from a paired phone
throw new Refusal(409, 'already_there', 'That item is already in the pantry.');
```

- `signedIn: true`: a signed-in person (browser or paired phone), or 401 `signed_out`.
- An app's own Bearer credential: `Authorization: Bearer` without the framework's `cave_` prefix passes through with `req.session` null and no cookie read, for a route that checks a key the app issued itself. `signedIn` routes still refuse it. Its writes need no `X-Cave-Request`: that rule protects cookie sessions, and another site's page can't set `Authorization` without a CORS preflight, which is never granted. The framework's own phone credentials keep every rule.
- `browserOnly: true`: a paired phone gets 403 `bearer_not_allowed`, never 401, which would make it unpair.
- `tokenOnly: true`: the route checks its own token (an agent API, for example). No cookie or phone credential is read for it (`req.session` is null), so the X-Cave-Request rule is skipped too. The route must authenticate every request. Not with `signedIn` or `browserOnly`.
- Fastify's own `bodyLimit` on a route raises the 1 MB default for that route only, such as an upload; a larger body elsewhere still gets 413 `too_large`.
- `req.session`: `{ kind: 'browser' | 'device', person: { subject, name, email, role }, sid, authTime, amr }`, or `null`. `role` is `owner` for the owner of Cougar Cave (`isOwner`, below), worked out on every request.

### The trust decision (1.3.0, Den Library 175)

Apps never work out who is trusted themselves. Three helpers, and one component in `@cougarcave/ui`:

| Helper | What it answers |
|---|---|
| `isOwner(req.session)` | The owner of Cougar Cave: the owner console's one owner list, read from cave-db's `core.owners` (cached a minute). Until cave-db has that view, the app's `OWNERS` setting decides, as before; once the view answers, `OWNERS` is ignored. `requireOwner(req, ask)` refuses everyone else with `owner_only` and an "ask the owner" fix saying what to ask for. |
| `isConfirmed(req.session)` | The person confirmed it's them: the shared sign-in used the second factor (`amr` has `mfa`, with or without `pwd`). No age check: it lasts until sign-out, and a confirmation in one app counts in every app. Never true for a phone. |
| `requireConfirmed(req, what)` | Only for the confirm list: show or lend a secret; delete a person, an app or data; change who may sign in or the sign-in rules; change AI keys or the overall money limit. Nothing else may ask. Refuses with 403 `needs_confirm` and a `confirm` fix; the kit's `api()` then confirms in a small window and sends the same request again, so the person stays where they were. A phone gets `browser_needed`. |

```ts
app.post('/api/secrets/:id/show', { config: { signedIn: true } }, async (req) => {
  requireConfirmed(req, 'Showing a secret');
  return show(req.params.id);
});
throw new Refusal(403, 'photos_off', 'Photos are off for you.', {}, { kind: 'ask_owner', ask: 'Turn on photos in Kitchen for me' });
```

Every refusal is `{"error", "message"}` plus, when there is one, `"fix": { kind, label?, href?, ask? }` with `kind` one of `confirm`, `signin`, `link`, `ask_owner`. Give every refusal a person can do something about a fix.

How confirming works: `/auth/login?confirm=1` asks the login service (`acr_values=cave-confirm`, no `max_age`) for the second factor. When the browser's shared sign-in already used it, nothing is shown; otherwise only the code is asked. If an older login service hands back a sign-in without it, the framework tries once more with the full form (`max_age=1`), then shows one sentence and a Try again button: it never loops. `/auth/confirmed` is where the confirm window lands; it tells the page and closes. If someone else signs in in that window, the page reloads instead of carrying on.

Deprecated, kept so apps still build: `isFresh(session)` is now true for any signed-in browser (nothing asks for a recent sign-in), `bothFactors(session)` is `isConfirmed(session)`, and `/auth/login?reauth=1` is a confirm. Adding a phone needs only a signed-in browser.

### Upgrading to 1.3.0

1. Bump `vendor/` to `cougarcave-server-1.3.0.tgz` and `cougarcave-ui-1.2.0.tgz`.
2. Replace your own owner checks (an `OWNERS` list, an admin flag, `role === 'owner'` of your own) with `isOwner` / `requireOwner`. Keep `OWNERS` in your settings until cave-db has `core.owners`; then delete it.
3. Delete `isFresh` checks. Replace `bothFactors` (and any "sign in again" step) with `requireConfirmed`, only for the confirm list; everything else needs nothing beyond `signedIn`.
4. Give your refusals a fix, and show refusals with `<cave-refusal>`; use `api()` from the kit so a confirm carries on by itself.
5. Drop `SIGNIN_POLICY_FILE` and its mount (no longer read). `AI_CALL_MAX_USD` and `AI_MAX_TOKENS` give way to the owner console's `per_call_usd` and `max_output_tokens` when it sets them; `ai.allowanceUsd()` is what a new person or household starts with ($1 a month unless the console says otherwise).
- `policy: { extend, paths }` in `createApp`: sources an app adds to the strict page policy, everywhere (`extend`) or for paths starting with a prefix (`paths: { '/cast/': {...} }`). Only safe additions are accepted, and anything else stops the app at start: `data:`/`blob:` images and media, `'wasm-unsafe-eval'`, https hosts, and `*` for connections, images and media. Never anything inline or `eval`, and never `data:` scripts or styles.
- `onLogout(subject, sid)` and `ignoreLogout(subject, sid)` in `createApp`: for what an app keeps itself (its own device keys) on a back-channel logout. `onLogout` is called after the framework has ended its own sessions and phones; `subject` is null when only an unknown sid was named. `ignoreLogout` is asked first: true marks the app's own session (one it opened and ended itself), and then the framework ends nothing and calls nothing, though the token still counts as used. Both fail closed: if `ignoreLogout` throws, the logout goes ahead. If `onLogout` throws, the framework's own sessions have already ended; the error is logged, without the token or the person, and the logout is answered as processed.
- `rawHosts: { 'gate.example.test': (req, res) => … }` in `createApp`: requests whose Host is exactly that name (any case, any port) go to the raw Node handler before every framework rule: no policy or headers, no X-Cave-Request check, no body parsing, no session. For a gate that proxies another service (streaming, uploads); the handler checks who may use it. The app's own host can't be one.
- `managedRawHosts: new ManagedRawHosts()` explicitly enables a separate trusted in-process host set, including when initially empty. After startup, `registry.replace({ 'gate.example.test': handler })` atomically replaces that whole managed set; `registry.snapshot()` reads the installed names and revision. `replace({})` removes it. Static `rawHosts`, the app's own name and their trailing-dot aliases stay reserved. No HTTP control route is added. The handlers still own all access checks; staged handlers must check active authority before proxying. Closing the app closes its registry.

## Settings

All from the environment, checked at start-up. Secrets are read from files.

| Setting | Default | Meaning |
|---|---|---|
| `APP_ORIGIN` | (required) | The address people use; cookies, redirects and QR codes use it |
| `HOST`, `PORT` | `127.0.0.1`, `8430` | Where to listen |
| `DATA_DIR` | `./data` | Local work's PGlite (`pg/`) and, for an app without `sideData: 'database'`, its side data file (`cave.db`) |
| `DEV_LOGIN` | off | The local stand-in for sign-in: 127.0.0.1 and http only |
| `OIDC_ISSUER`, `OIDC_CLIENT_ID`, `OIDC_CLIENT_SECRET_FILE` | | Cougar Cave sign-in, from the owner console's Add app |
| `OWNERS` | | Deprecated: the owner is the owner console's (`core.owners`). Read only while cave-db has no such view |
| `TRUSTED_PROXIES` | | Proxies whose `X-Forwarded-*` headers are trusted |
| `AI_SETTINGS_FILE` | `/run/cougar-ai/settings.json` | The owner console's shared AI settings, mounted read-only |
| `SIGNIN_POLICY_FILE` | | Deprecated and not read since 1.3.0: nothing asks for a recent sign-in |
| `AI_CALL_MAX_USD`, `AI_MAX_TOKENS` | `0.02`, `1024` | One AI call's limits, unless the owner console sets `per_call_usd` / `max_output_tokens` |
| `AI_FAKE` | off | The no-cost fake AI provider, with the dev login only |
| `SHARED_ORIGIN` | `https://cougarcave.dev` | Where the shared bar and app list load from |

## Tests

### Inline AI images (Kitchen #511 prerequisite, #744)

Text-only messages keep their existing contract. A user turn can also carry
`images: [{ mediaType: 'image/jpeg', data: bytes.toString('base64') }]`.
`AIImage` is exported; PNG and WebP are also accepted. Supply canonical base64 bytes, never a URL or file path.
Malformed base64, unrecognized image headers, a mismatched media type or images on an assistant turn produce
400 `ai_image_invalid` before token counting. Header checks do not fully decode or sanitize an image.
The caller must bound uploads and image dimensions, strip metadata and dispose of its photo buffers/files.
The helper does not store image bytes, create provider files or fetch remote image URLs.

Both `estimate(request)` and `run(account, request, limits)` send images to the configured provider's counting
endpoint; estimation is therefore an external transmission even though it does not generate an answer.
Counting happens before generation budget reservation: obtain the person's consent before estimating too.
Generation uses the same inline image payload. Image input tokens participate in the existing typical/worst-case
estimate, per-call cap, household/app monthly reservation and provider-usage settlement, including invalid replies.
Gemini retains its conservative schema allowance. No image-token approximation or new provider/model default is added.
An unsupported model or failed count is refused through the existing provider error handling; it never falls back
to a text-only request. The fake accepts the same request and uses deterministic synthetic usage, without network.

Provider wire formats: [Anthropic vision](https://platform.claude.com/docs/en/build-with-claude/vision),
[OpenAI vision](https://developers.openai.com/api/docs/guides/images-vision),
[Gemini image understanding](https://ai.google.dev/gemini-api/docs/image-understanding).
Counting contracts: [OpenAI token counting](https://developers.openai.com/api/docs/guides/token-counting),
[Gemini tokens](https://ai.google.dev/gemini-api/docs/tokens).
No real provider execution is part of this prerequisite's automated checks.

### Paw AI conversations (server only)

`PawAIAdapter` wraps the existing `app.cave.ai`; it creates no settings, provider, ledger or authentication service.
Construct `new PawAIAdapter(app.cave.ai, authorize)` in the server. `authorize(context, conversationId)` must
resolve the currently authenticated central subject, check current conversation/account membership and revocation,
and return `{ account, person, accountLimitUsd }`, or `null` to deny. These are authoritative server values.
The shared `Session.person.subject` identifies a person; it does **not** establish an account membership.
Paw computer certificates, OS usernames and display names do not establish that membership either.

`run(context, { conversationId, messages })` accepts a UUID and up to 32 user/assistant text turns (8000 characters
each, 32000 total, ending in a user turn). Lab must build this input from authorized stored history, after checking
the desktop's request. Do not pass an arbitrary desktop transcript as authoritative history. Client account,
person, budgets, system prompts, models and tools are rejected. The result is the existing `AIResult<{text:string}>`.
Existing refusal codes and accounting apply; the host should use its normal safe error response handling.
Authorization is checked on each invocation; this adapter is not a transport route or an identity verifier.

**Host tools (1.2.5).** `new PawAIAdapter(app.cave.ai, authorize, { system, tools })` offers the model the host's
tools (Anthropic and the fake provider; OpenAI and Gemini refuse with `ai_tools_unsupported`). Each tool is
`{ name, description, input: zodSchema, call(context, input) }`. The model's arguments arrive unchecked: `call` must
apply the host's own policy and returns the only text the model is told. A turn is at most two generations: the
first may call a tool, the host answers the first call (others get "Not run"), and the second lets the model reply.
The result adds `calls: [{ name, input, result, handled }]`; if the second generation fails the turn still returns,
with empty text. This package runs nothing for a tool call. Without tools, behaviour is unchanged.
Since 1.2.6, a request with tools does not force the JSON reply format (live, a forced JSON reply kept the model
from calling tools): the model answers with a tool call or plain text, and `runTools` returns that as `text`, with
`data` only when the text also matches the schema. Without tools the JSON format is forced exactly as before.
For other uses, `app.cave.ai.runTools(account, { ...request, tools }, limits)` returns the reply (or `null`) and
`toolCalls`; answer them with an assistant turn carrying `toolCalls` and a user turn carrying `toolResults`.

`capabilities` reports `{ cancellation: false, actions: false }`: the existing helper/provider interface cannot
cancel an in-flight request. A UI may stop displaying a reply, but must not claim provider cancellation or reverse
ledger charges. Replies are text proposals only; executing an action requires the application's separate explicit
authorization and Jobs flow. Provider keys and this adapter remain on the server. Paid-provider execution,
end-to-end Lab routing and Paw UI acceptance are separate integration work.

`npm test`: settings, security, sign-in, back-channel logout, pairing and AI. Each refusal is checked for its code beside a working control, and the important rules have been break-checked (each one, when broken, fails a test).

## Apps with their own AI ledger

With database side data, set `createApp({ sideData: 'database', aiSpendView: 'app' })` if the app maintains its own `cave_ai_month` view. The framework still creates its side tables, copies an existing side-data file and enforces its AI limits, but does not create, replace or grant access to that view. This also works on the first start before the app creates its view.

The app must create a totals-only view with `app`, `month`, `billed_micros` and `calls`, and grant the existing `cave_spend` role SELECT on the view and USAGE on its schema. Never expose people, accounts, models or ledger rows. Keep the view definition and grants in the app's migrations or startup. Without this option, the framework continues to maintain its own view on every start. Switching back to the default replaces an app view, so migrate deliberately.

The option requires `sideData: 'database'`; other modes and unknown values are refused before storage opens. When replacing an existing framework view with a custom view whose column types differ, drop and recreate the view in one migration transaction, then reapply its grants. `CREATE OR REPLACE VIEW` cannot change existing column types; dropping a view removes its grants. Never use CASCADE here, and keep the app's totals-only contract.
