# @cougarcave/ui

The Cougar Cave look and its shared components: Web Awesome with the Cougar Cave themes, and Lit components in TypeScript. `@cougarcave/server` serves the built kit at `/cave/`.

## A page

```html
<script src="/cave/cave-theme.js"></script>                       <!-- theme first: no flash -->
<link rel="stylesheet" href="/cave/webawesome/styles/webawesome.css">
<link rel="stylesheet" href="/cave/cave-theme.css">
<script type="module" src="/cave/webawesome/webawesome.loader.js" data-webawesome="/cave/webawesome"></script>
<script type="module" src="/cave/cave-icons.js"></script>
<script type="module" src="/cave/cave-ui.js"></script>
```

## Components

| Tag | What it is |
|---|---|
| `<cave-bar>` | The bar at the top of every app: home, the app's name, the app menu (from `https://cougarcave.dev/apps.json`, cached), the account menu, "Owner console" only for owners. `mode="full | compact | hidden"`, `slot="app"` for app controls, `slot="actions"` for up to two buttons. |
| `<cave-account>` | The bar's account menu |
| `<cave-signin>` | The sign-in card: one way in, Cougar Cave |
| `<cave-settings>` | The settings drawer; `<section data-section data-label data-icon>` children become its sections, plus Appearance |
| `<cave-pair-device>`, `<cave-devices>` | Add a phone (QR code and PIN, no polling) and the Phones list |
| `<cave-ai-confirm>`, `<cave-ai-status>`, `<cave-ai-result>` | The AI helper: the cost before a call, the month's spend, the answer with Save buttons |

Apps build their own components on the same copy of Lit: `import { CaveElement, html, api } from '/cave/cave-ui.js'`. Components render into the page (no shadow root), so `cave-theme.css` styles them. Lit escapes everything it puts in a template, so text from people or a model never becomes HTML.

`api(path, { method, body })` sends `X-Cave-Request: 1` and the session cookie, and throws `ApiError` with `status`, `code` and the server's message.

## No flash

Put the bar's static markup inside `<cave-bar>` (as the app template does). It has the same box as the drawn bar, and `cave-theme.css` reserves the size of Web Awesome tags until they're defined, so nothing on the page moves when the bar takes over.

## The shared bar

`npm run build` also writes `dist/cave-bar.js`: the bar and what it opens, with Lit bundled, for serving from `https://cougarcave.dev/cave/`, so one update changes every app's bar. It defines nothing a page already has.

## Build and test

`npm run build` writes `dist/`: `cave-ui.js`, `cave-bar.js`, types, the theme, icons, fonts and Web Awesome from npm. `npm test` builds, then runs the component tests, including the strict-page-policy check (no `data:` images anywhere the kit owns).
